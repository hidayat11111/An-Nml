import PageRouting from './Components/PageRouting';
import { BrowserRouter } from 'react-router-dom';

function App() {
  return (
    
    <BrowserRouter>
    
<PageRouting/>
    
</BrowserRouter>

  );
}

export default App;
